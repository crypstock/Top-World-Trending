from scripts.amazon_search import buscar_amazon
from scripts.ebay_search import buscar_ebay
from scripts.mercado_libre import buscar_mercado_libre
import os

def main():
    print("Bienvenido a TopWorldTrending – Buscador de Productos en Tendencia!")
    print("Selecciona una plataforma para buscar productos:")
    print("1. Amazon")
    print("2. eBay")
    print("3. Mercado Libre")

    opcion = input("Elige una opción (1/2/3): ")

    producto = input("🔍 ¿Qué producto deseas buscar?: ")

    if opcion == "1":
        resultados = buscar_amazon(producto)
    elif opcion == "2":
        resultados = buscar_ebay(producto, os.getenv("EBAY_APP_ID"))
    elif opcion == "3":
        resultados = buscar_mercado_libre('MLM', producto)
    else:
        print("Opción inválida")
        return

    if resultados:
        print("\n🔎 Resultados encontrados:")
        for i, prod in enumerate(resultados, 1):
            print(f"{i}. {prod['titulo']} - ${prod['precio']} - {prod.get('url') or prod.get('link')}")
    else:
        print("No se encontraron resultados.")

if __name__ == "__main__":
    main()

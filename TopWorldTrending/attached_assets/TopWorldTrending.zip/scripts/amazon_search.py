import os
def buscar_amazon(query):
    print("⚠️ Amazon API requiere integración completa con firma. Aquí va tu lógica real.")
    return [{"titulo": f"{query} Amazon Simulado", "precio": 199.99, "url": "https://amazon.com"}]

import requests
def buscar_mercado_libre(pais='MLM', query='laptop', limite=10):
    base_url = f"https://api.mercadolibre.com/sites/{pais}/search?q={query}&limit={limite}"
    respuesta = requests.get(base_url)
    if respuesta.status_code == 200:
        datos = respuesta.json()
        productos = datos['results']
        resultados = []
        for producto in productos:
            resultados.append({
                'titulo': producto['title'],
                'precio': producto['price'],
                'link': producto['permalink'],
                'imagen': producto['thumbnail']
            })
        return resultados
    else:
        print("Error en la búsqueda:", respuesta.status_code)
        return []
